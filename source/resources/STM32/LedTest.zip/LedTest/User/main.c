#include "stm32f10x.h"
#include "stm32f10x_conf.h"

static void delay(u16 n)
{
	int i = 0;
	while(n--)
	{
		i = 10000;
		while(i--);
	}
}

int main(void)
{

  /* GPIOA Periph clock enable */
	GPIO_InitTypeDef GPIO_InitStructure;
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);

  /* Configure PA0 and PA2 in output pushpull mode */
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_Init(GPIOA, &GPIO_InitStructure);

	int i = 5;
  while (i--)
  {
		GPIO_SetBits( GPIOA, GPIO_Pin_0 );
		delay( 100 );
		GPIO_ResetBits( GPIOA, GPIO_Pin_0 );
		delay( 100 );
  }
}
