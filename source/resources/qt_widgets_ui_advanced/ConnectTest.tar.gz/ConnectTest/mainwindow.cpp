#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QLabel>
#include <QLineEdit>
#include <QMetaMethod>
#include <QDebug>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    QLineEdit *line_edit = new QLineEdit(this);
    QLabel *label = new QLabel(this);
    label->move(0,40);

    // connect 1
    QObject::connect(line_edit, SIGNAL(textChanged(QString)), label, SLOT(setText(QString)));

    // connect 2
//    label->connect(line_edit, SIGNAL(textChanged(QString)), SLOT(setText(QString)));

    // connect 3
//    QObject::connect(line_edit, &QLineEdit::textChanged, label, &QLabel::setText);

    // connect 4
//    QMetaMethod signal = QMetaMethod::fromSignal(&QLineEdit::textChanged);
//    int slot_index = label->metaObject()->indexOfMethod("setText(QString)");
//    QMetaMethod slot = label->metaObject()->method( slot_index );
//    QObject::connect(line_edit, signal, label, slot);

    // connect 5
//    QObject::connect(line_edit, &QLineEdit::textChanged, [=](QString text){label->setText(text);});

    // connect 6
//    QObject::connect(line_edit, &QLineEdit::textChanged, this, [=](QString text){label->setText(text);});
}

MainWindow::~MainWindow()
{
    delete ui;
}
