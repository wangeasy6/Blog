#ifndef VIRTUAL_KEYBOARD_H
#define VIRTUAL_KEYBOARD_H

#include <QtQuickWidgets/QQuickWidget>

extern QQuickWidget *v_keyboard;

#endif // VIRTUAL_KEYBOARD_H
