'''
程序功能：根据WBS计划分解表（xlsx、xlxm）的事件、开始时间、交付时间，自动生产计划甘特图表。

特色：合并多个WBS计划表为一个甘特图，方便查看时间冲突，做统筹规划。
打包：pyinstaller -Fw --clean gantt_char_generator.py
'''

#!/usr/bin/python3
# -*- coding: utf-8 -*-

import os
import sys
import json
import datetime
from PyQt5.QtCore import Qt
#from PyQt5.QtWidgets import *
from PyQt5.QtWidgets import QMessageBox,QLabel,QWidget,QApplication,QPushButton, \
    QLineEdit,QVBoxLayout,QHBoxLayout,QFileDialog
#from PyQt5.QtGui import QIcon
from openpyxl import load_workbook
from openpyxl import Workbook
from openpyxl.utils import get_column_letter
from openpyxl.styles import PatternFill

class MainWindow(QWidget):

    def __init__(self):
        super().__init__()
        #界面绘制交给InitUi方法
        self.initUI()

    def initUI(self):
        self.v_body = QVBoxLayout()

        line = QHBoxLayout()
        lb_doc = QLabel("文件")
        le_doc = QLineEdit()
        lb_sheet_title = QLabel("表名:")
        le_sheet_title = QLineEdit()
        le_doc.setObjectName("doc")
        lb_line_start = QLabel("Line :")
        le_line_start = QLineEdit()
        lb_line_end = QLabel(" - ")
        le_line_end = QLineEdit()
        lb_activity = QLabel("事件列:")
        le_activity = QLineEdit()
        lb_start_time = QLabel("开始时间列:")
        le_start_time = QLineEdit()
        lb_end_time = QLabel("结束时间列:")
        le_end_time = QLineEdit()


        line.addWidget(lb_doc)
        line.addWidget(le_doc)
        line.addWidget(lb_sheet_title)
        line.addWidget(le_sheet_title)
        line.addWidget(lb_line_start)
        line.addWidget(le_line_start)
        line.addWidget(lb_line_end)
        line.addWidget(le_line_end)
        line.addWidget(lb_activity)
        line.addWidget(le_activity)
        line.addWidget(lb_start_time)
        line.addWidget(le_start_time)
        line.addWidget(lb_end_time)
        line.addWidget(le_end_time)
        #line.addWidget()

        add_line = QHBoxLayout()
        bt_load_config = QPushButton("Load Config")
        bt_load_config.clicked.connect(self.loadConfig)
        bt_add_line = QPushButton("Add Input Line")
        bt_add_line.clicked.connect(self.addInputLine)
        add_line.addStretch()
        add_line.addWidget(bt_load_config, 0, Qt.AlignRight)
        add_line.addWidget(bt_add_line, 0, Qt.AlignRight)

        output_line = QHBoxLayout()
        lb_dir = QLabel("文件夹:")
        self.le_dir = QLineEdit()
        self.le_dir.setObjectName("doc")
        lb_out_doc = QLabel("文件名:")
        self.le_out_doc = QLineEdit()
        self.le_out_doc.setObjectName("doc")
        #self.cb_is_sort = QCheckBox("自动排序")
        bt_start = QPushButton("开始生成")
        bt_start.clicked.connect(self.generate)

        output_line.addWidget(lb_dir)
        output_line.addWidget(self.le_dir)
        output_line.addWidget(lb_out_doc)
        output_line.addWidget(self.le_out_doc)
        #output_line.addWidget(self.cb_is_sort)
        output_line.addStretch()
        output_line.addWidget(bt_start)
        #output_line.addWidget()


        self.v_body.addLayout(line)
        self.v_body.addLayout(add_line)
        self.v_body.addStretch()
        self.v_body.addLayout(output_line)
        self.v_body.setSpacing(10)
        self.setLayout(self.v_body)

        #设置窗口的位置和大小
        self.setGeometry(600, 600, 900, 600)
        #设置窗口的标题
        self.setWindowTitle('甘特图生成器')
        #设置窗口的图标，引用当前目录下的icon.png图片
        #self.setWindowIcon(QIcon('icon.png'))

        with open('gantt_char_generator.qss', 'r') as f:
            self.setStyleSheet(f.read())

        #显示窗口
        self.show()


    def loadConfig(self):
        directory = QFileDialog.getOpenFileName(self,
              "getOpenFileName","./",
              "Text Files (*.json);;All Files (*)")

        #print(directory)
        if directory[0] == '':
            # QMessageBox.warning(self, "Tips", "选择文件为空！")
            return

        with open(directory[0], 'r', encoding='utf8')as fp:
            try:
                cfg = json.load(fp)
                #print(cfg)
            except Exception as e:
                QMessageBox.warning(self, "Tips", "加载Json：" + str(e))
                return
            else:
                pass
            finally:
                fp.close()

            if 'Input' not in cfg:
                QMessageBox.about(self, "Tips", "Json 未指定 Input！")
                return

            for info in cfg['Input']:
                if "file" not in info:
                    QMessageBox.warning(self, "Tips", 'Input "file"为空！')
                    continue

                if "sheet_title" not in info or \
                "line_start" not in info or \
                "line_end" not in info or \
                "activity_col" not in info or \
                "start_time_col" not in info or \
                "end_time_col" not in info:
                    QMessageBox.warning(self, "Tips", '"' + info["file"] + '"项目不全！')
                    continue

                line = QHBoxLayout()
                lb_doc = QLabel("文件")
                le_doc = QLineEdit(info["file"])
                lb_sheet_title = QLabel("表名:")
                le_sheet_title = QLineEdit(info["sheet_title"])
                le_doc.setObjectName("doc")
                lb_line_start = QLabel("Line :")
                le_line_start = QLineEdit(info["line_start"])
                lb_line_end = QLabel(" - ")
                le_line_end = QLineEdit(info["line_end"])
                lb_activity = QLabel("事件列:")
                le_activity = QLineEdit(info["activity_col"])
                lb_start_time = QLabel("开始时间列:")
                le_start_time = QLineEdit(info["start_time_col"])
                lb_end_time = QLabel("结束时间列:")
                le_end_time = QLineEdit(info["end_time_col"])

                line.addWidget(lb_doc)
                line.addWidget(le_doc)
                line.addWidget(lb_sheet_title)
                line.addWidget(le_sheet_title)
                line.addWidget(lb_line_start)
                line.addWidget(le_line_start)
                line.addWidget(lb_line_end)
                line.addWidget(le_line_end)
                line.addWidget(lb_activity)
                line.addWidget(le_activity)
                line.addWidget(lb_start_time)
                line.addWidget(le_start_time)
                line.addWidget(lb_end_time)
                line.addWidget(le_end_time)

                self.v_body.insertLayout(0, line)

            if 'Output' in cfg:
                if 'path' in cfg['Output']:
                    self.le_dir.setText(cfg['Output']['path'])
                if 'file' in cfg['Output']:
                    self.le_out_doc.setText(cfg['Output']['file'])


    def addInputLine(self):
        line = QHBoxLayout()
        lb_doc = QLabel("文件")
        le_doc = QLineEdit()
        lb_sheet_title = QLabel("表名:")
        le_sheet_title = QLineEdit()
        le_doc.setObjectName("doc")
        lb_line_start = QLabel("Line :")
        le_line_start = QLineEdit()
        lb_line_end = QLabel(" - ")
        le_line_end = QLineEdit()
        lb_activity = QLabel("事件列:")
        le_activity = QLineEdit()
        lb_start_time = QLabel("开始时间列:")
        le_start_time = QLineEdit()
        lb_end_time = QLabel("结束时间列:")
        le_end_time = QLineEdit()

        line.addWidget(lb_doc)
        line.addWidget(le_doc)
        line.addWidget(lb_sheet_title)
        line.addWidget(le_sheet_title)
        line.addWidget(lb_line_start)
        line.addWidget(le_line_start)
        line.addWidget(lb_line_end)
        line.addWidget(le_line_end)
        line.addWidget(lb_activity)
        line.addWidget(le_activity)
        line.addWidget(lb_start_time)
        line.addWidget(le_start_time)
        line.addWidget(lb_end_time)
        line.addWidget(le_end_time)

        self.v_body.insertLayout(0, line)

    def generate(self):
        """
        根据输入的文件，输出甘特图Excel。
        """
        directory = self.le_dir.text()
        if directory == "":
            directory = '.'
        if not os.path.exists(directory):
            QMessageBox.warning(self, "Tips", "错误的输出文件路径！")
            return

        dest_filename = directory + '/' + self.le_out_doc.text()
        print(dest_filename)
        wb_gantt = Workbook()
        gantt_char = wb_gantt.active
        gantt_char.title = "Gantt Char"

        # 表头
        gantt_char.append(['自动甘特图', '当前日期：', '=TODAY()'])
        gantt_char.append(['源文件', '任务内容', '开始时间', '结束时间', '进度' ])
        gantt_char.column_dimensions['A'].width = 20.0
        gantt_char.column_dimensions['B'].width = 25.0
        gantt_char.column_dimensions['C'].width = 12.0
        gantt_char.column_dimensions['D'].width = 12.0
        gantt_char.row_dimensions[1].height = 20
        gantt_char.cell(row=1, column=3).number_format = 'yy-mm-dd'

        # 遍历表List
        insert_row_i = 3
        max_datetime = datetime.datetime.strptime('1970-01-01 00:00:00', '%Y-%m-%d %H:%M:%S')
        min_datetime = datetime.datetime.strptime('2500-01-01 00:00:00', '%Y-%m-%d %H:%M:%S')
        for i in range(self.v_body.count() - 3):
            # 输入Path检测
            path = self.v_body.itemAt(i).itemAt(1).widget().text()
            if path == "":
                continue
            if not os.path.exists(path):
                QMessageBox.warning(self, "Tips", "Input file :\"" + path +"\"不存在！")
                continue

            # 输入项目检测
            sheet_title = self.v_body.itemAt(i).itemAt(3).widget().text()
            line_start = self.v_body.itemAt(i).itemAt(5).widget().text()
            line_end = self.v_body.itemAt(i).itemAt(7).widget().text()
            activity_column = self.v_body.itemAt(i).itemAt(9).widget().text()
            start_time_column = self.v_body.itemAt(i).itemAt(11).widget().text()
            end_time_column = self.v_body.itemAt(i).itemAt(13).widget().text()

            if sheet_title == "" or \
            line_start == "" or \
            line_end == "" or \
            activity_column == "" or \
            start_time_column == "" or \
            end_time_column == "":
                QMessageBox.warning(self, "Tips", '"' + path + '"项目不全！')
                continue

            try:
                line_start = int(line_start)
            except Exception as e:
                QMessageBox.warning(self, "Tips", 'Line Start 项非数字！')
                continue
            try:
                line_end = int(line_end)
            except Exception as e:
                QMessageBox.warning(self, "Tips", 'Line End 项非数字！')
                continue
            try:
                activity_column = int(activity_column)
            except Exception as e:
                QMessageBox.warning(self, "Tips", '事件列非数字！')
                continue
            try:
                start_time_column = int(start_time_column)
            except Exception as e:
                QMessageBox.warning(self, "Tips", '开始时间列非数字！')
                continue
            try:
                end_time_column = int(end_time_column)
            except Exception as e:
                QMessageBox.warning(self, "Tips", '结束时间列非数字！')
                continue

            print(path, " , ", line_start, " , ", line_end, " , ", \
                activity_column, " , ", start_time_column, " , ", end_time_column)

            # 打开表
            wb_input = load_workbook(filename = path, data_only = True)
            if sheet_title not in wb_input:
                QMessageBox.warning(self, "Tips", "\"" + path + "\"中找不到表 : " + sheet_title)
                continue
            input_sheet = wb_input[sheet_title]

            # 遍历单个表
            file_name = path.split('/')[-1]
            for n in range(line_start, line_end+1):
                gantt_char.cell(row=insert_row_i, column=1).value = file_name
                gantt_char.cell(row=insert_row_i, column=2).value = input_sheet.cell(row=n, column=activity_column).value
                start_time = input_sheet.cell(row=n, column=start_time_column).value
                gantt_char.cell(row=insert_row_i, column=3).value = start_time
                gantt_char.cell(row=insert_row_i, column=3).number_format = 'yy-mm-dd'
                end_time = input_sheet.cell(row=n, column=end_time_column).value
                gantt_char.cell(row=insert_row_i, column=4).value = end_time
                gantt_char.cell(row=insert_row_i, column=4).number_format = 'yy-mm-dd'

                if start_time < min_datetime:
                    min_datetime = start_time
                if end_time > max_datetime:
                    max_datetime = end_time
                insert_row_i += 1
            wb_input.close()

        if insert_row_i == 3:
            QMessageBox.about(self, "Tips", "输入的表中无数据导出，无输出！")
            return

        # Fill日期轴
        n_day = 0
        if max_datetime != datetime.datetime.strptime('1970-01-01 00:00:00', '%Y-%m-%d %H:%M:%S'):
            delta = max_datetime - min_datetime
            n_day = delta.days

            for j in range(n_day + 1):
                gantt_char.cell(row=2, column=6+j).value = min_datetime + datetime.timedelta(days=j)
                gantt_char.cell(row=2, column=6+j).number_format = 'd-m'
                column_letter = get_column_letter((6+j))
                gantt_char.column_dimensions[column_letter].width = 6

        # 画甘特图
        #lead_day_fill = PatternFill("solid", fgColor="00FF00")  # 提前量
        mission_fill = PatternFill("solid", fgColor="008B00")   # 当前效果
        #lag_fill = PatternFill("solid", fgColor="FF4500")       # 滞后量
        for n in range(3, insert_row_i):
            start_time = gantt_char.cell(row=n, column=3).value
            end_time = gantt_char.cell(row=n, column=4).value

            gantt_char.cell(row=n, column=5).value = \
                "=IF(C1<C"+str(n)+",0,IF(C1<D"+str(n)+ \
                ",(C1-C"+str(n)+")/(D"+str(n)+"-C"+str(n)+"),1))"
            gantt_char.cell(row=n, column=5).number_format = '0.0%'
            for i in range(n_day+1):
                if gantt_char.cell(row=2, column=6+i).value >= start_time:
                    gantt_char.cell(row=n, column=6+i).fill = mission_fill
                if gantt_char.cell(row=2, column=6+i).value >= end_time:
                    break

        # 冻结窗口
        gantt_char.freeze_panes = 'F' + str(insert_row_i)

        # 保存文件
        try:
            wb_gantt.save(dest_filename)
            QMessageBox.about(self, "Tips", "输出：\"" + dest_filename + '"')
        except Exception as e:
            print(e)
            QMessageBox.about(self, "Tips", "成功生成：\"" + dest_filename + '"错误：' + str(e))
        finally:
            wb_gantt.close()



if __name__ == '__main__':
    #创建应用程序和对象
    app = QApplication(sys.argv)
    mw = MainWindow()
    sys.exit(app.exec_())