function getVersion()
{
    var xml_http;
    if (window.XMLHttpRequest)
        xml_http = new XMLHttpRequest();     // code for IE7+, Firefox, Chrome, Opera, Safari
    else
        xml_http = new ActiveXObject("Microsoft.XMLHTTP");// code for IE6, IE5

    if (xml_http!=null)
    {
        xml_http.onreadystatechange=function()
        {
            if (xml_http.readyState==4 && xml_http.status==200)
            {
                var temp = xml_http.responseText;
                console.log(temp);
                var obj = JSON.parse(temp);
                if(obj.result=="True" && obj.version)
                    document.getElementById("txt_software_ver").value = obj.version;
                else
                    window.alert("获取失败");
            }
        }
        xml_http.open("GET","/get_version.cgi",true);
        xml_http.send();
    }
    else
    {
        alert("Your browser does not support XMLHTTP.");
    }
}


function setVersion()
{
    var post_string = '/set_version.cgi?' + document.getElementById("txt_software_ver").value;
    var xml_http;
    if (window.XMLHttpRequest)
        xml_http = new XMLHttpRequest();     // code for IE7+, Firefox, Chrome, Opera, Safari
    else
        xml_http = new ActiveXObject("Microsoft.XMLHTTP");// code for IE6, IE5

    xml_http.onreadystatechange=function()
    {
        if (xml_http.readyState==4 && xml_http.status==200)
        {
            var temp = xml_http.responseText;
            console.log(temp);
            var obj = JSON.parse(temp);
            window.alert(obj.result=="True"?"设置成功":("设置失败" + "\r\n" + obj.message));
        }
    }
    xml_http.open("POST",post_string,true);
    xml_http.send();
}


function postImage()
{
    if(image == "")
    {
        window.alert("请先选择照片");
        return;
    }

    var xml_http;
    if (window.XMLHttpRequest)
        xml_http = new XMLHttpRequest();     // code for IE7+, Firefox, Chrome, Opera, Safari
    else
        xml_http = new ActiveXObject("Microsoft.XMLHTTP");// code for IE6, IE5

    var post_string = '/post_image.cgi?' + img_md5;
    console.log(post_string);
    xml_http.onreadystatechange=function()
    {
        if (xml_http.readyState==4 && xml_http.status==200)
        {
            var temp = xml_http.responseText;
            console.log(temp);
            var obj = JSON.parse(temp);
            window.alert(obj.result=="True"?"上传成功":("上传失败" + "\r\n" + obj.message));
        }
    }
    xml_http.open("POST", post_string, true);
    xml_http.send(image);
}
