#include <iostream>
#include <fstream>
#include <string.h>
#include "char_md5.h"
using namespace std;

string version = "1.0";


void getVersion()
{
    cout << "Content-type:text/html\r\n\r\n";
    cout << "{\"result\":\"True\", \"message\":\"Success\", " <<  \
        "\"version\":\"" << version << "\"}\n";
}


void setVersion(char *query_str)
{
    cout << "Content-type:text/html\r\n\r\n";
    if(!query_str)
    {
        cout << "{\"result\":\"False\", \"message\":\"参数有误\"}\n";
        return;
    }
    
    version = query_str;

    cout << "{\"result\":\"True\", \"message\":\"Success\"}\n";
}


void postImage(char *query_str, char *content_len)
{
    cout << "Content-type:text/html\r\n\r\n";
    if(!content_len || !query_str)
    {
        cout << "{\"result\":\"False\", \"message\":\"参数有误\"}\n";
        return;
    }

    // 接收&存储 照片
    int len = atoi(content_len);
    char md5_str[MD5_CHAR_LEN];
    if (len > 0)
    {
        char img[len];
        for (int i=0; i < len; i ++)
        {
            img[i] = cin.get();
        }
        if (img)
        {
            //cout << "Conten Len :" << len << endl;
            //cout << "Image Len:" << strlen(img) << endl;
            const char* fileName = "./image.jpg";
            ofstream f(fileName, ios::out | ios::binary);
            f.write(img, len);
            f.close();

            Compute_string_md5((unsigned char *)img, len, md5_str);
        }
    }
    else
    {
        cout << "{\"result\":\"False\", \"message\":\"image数据为空\"}\n";
        return;
    }

    string md5sum = query_str;
    if(strcmp(md5_str, query_str) != 0)
    {
        cout << "{\"result\":\"False\", \"message\":\"文件MD5校验有误\"}\n";
        return;
    }

    cout << "{\"result\":\"True\", \"message\":\"Success\"}\n";
}
