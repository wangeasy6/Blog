#ifndef __URLS__
#define __URLS__

void getVersion();
void setVersion(char *query_str);
void postImage(char *query_str, char *content_len);

#endif
