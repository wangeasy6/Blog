#include <iostream>
#include <string.h>
#include "fcgio.h"
#include "urls.h"
using namespace std;

int main (int argc, char *argv[])
{
    streambuf *cin_streambuf = cin.rdbuf();
    streambuf *cout_streambuf = cout.rdbuf();
    //streambuf *cerr_streambuf = cerr.rdbuf();

    FCGX_Init();
    FCGX_Request request;
    FCGX_InitRequest(&request, 0, 0);

    while(FCGX_Accept_r(&request) == 0)
    {
        fcgi_streambuf cin_fcgi_streambuf(request.in);
        fcgi_streambuf cout_fcgi_streambuf(request.out);
        //fcgi_streambuf cerr_fcgi_streambuf(request.err);      # 取消托管cerr，在调试的时候使用cerr可以直接输出

        cin.rdbuf(&cin_fcgi_streambuf);
        cout.rdbuf(&cout_fcgi_streambuf);
        //cerr.rdbuf(&cerr_fcgi_streambuf);

        char *request_uri = FCGX_GetParam("REQUEST_URI", request.envp);
        char *query_str = FCGX_GetParam("QUERY_STRING", request.envp);
        char *content_len = FCGX_GetParam("CONTENT_LENGTH", request.envp);

        if ( strstr(request_uri, "get_version.cgi") )
        {
            getVersion();
            continue;
        }
        if ( strstr(request_uri, "set_version.cgi") )
        {
            setVersion(query_str);
            continue;
        }
        if ( strstr(request_uri, "post_image.cgi") )
        {
            postImage(query_str, content_len);
            continue;
        }

        cout << "Content-type:text/html\r\n\r\n";
        cout << "{\"result\":\"False\", \"message\":\"Protocol not supported\"}\n";
    }

    cin.rdbuf(cin_streambuf);
    cout.rdbuf(cout_streambuf);
    //cerr.rdbuf(cerr_streambuf);

    return 0;
}
