﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JsonExampleCShape
{
    class Program
    {
        static void Main(string[] args)
        {
            Read();
            Write();
            Console.ReadLine();
        }

        private static void Read()
        {
            JObject json = JsonConvert.DeserializeObject<JObject>(File.ReadAllText("json_example.json"));
            Console.WriteLine(json.GetType());
            Console.WriteLine(json);

            Console.WriteLine(json["name"].GetType());
            Console.WriteLine(json["name"]);

            Console.WriteLine(json["personnel"].GetType());
            Console.WriteLine(json["personnel"]);

            foreach ( JObject person in json["personnel"] )
            {
                Console.WriteLine(person["name"].GetType());
                Console.WriteLine(person["name"]);
                Console.WriteLine(person["height"].GetType());
                Console.WriteLine(person["height"]);
                Console.WriteLine(person["is_married"].GetType());
                Console.WriteLine(person["is_married"]);
                Console.WriteLine(person["advice"].GetType());
                Console.WriteLine(person["advice"]);
            }
        }

        private static void Write()
        {
            JObject obj = new JObject();
            obj["name"] = "体检报告";

            JArray personnel = new JArray();
            JObject person = new JObject();
            person["name"] = "张三";
            person["height"] = 175;
            person["is_married"] = false;
            person["advice"] = null;
            personnel.Add(person);

            person = new JObject();
            person["name"] = "李四";
            person["height"] = 172.5;
            person["is_married"] = true;
            person["advice"] = "随访观察";
            personnel.Add(person);

            obj["personnel"] = personnel;

            string content = JsonConvert.SerializeObject(obj, Formatting.Indented);
            File.WriteAllText("output.json", content);

            Console.WriteLine("Write :\r\n" + content + "\r\nTo output.json");
        }
    }
}
