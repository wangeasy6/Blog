#include "message_box.h"
#include "ui_message_box.h"

#include <QGraphicsDropShadowEffect>
#include <QPainter>

MessageBox::MessageBox(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::MessageBox)
{
    ui->setupUi(this);

    this->setWindowFlags(Qt::FramelessWindowHint);          // 设置无窗体
    this->setAttribute(Qt::WA_TranslucentBackground);       // 设置背景透明

    // 相对父窗体居中
    if(this->parent() && this->parent()->isWidgetType())
    {
        this->move((this->parentWidget()->width() - this->width()) / 2,
               (this->parentWidget()->height() - this->height()) / 2);
    }

    // 阴影效果
    QGraphicsDropShadowEffect *shadow_effect = new QGraphicsDropShadowEffect(this);
    shadow_effect->setOffset(4,8);                          // 阴影偏移
    shadow_effect->setColor(QColor(0, 0x1E, 0x9A, 102));    // 阴影颜色
    shadow_effect->setBlurRadius(40);                       // 模糊半径
    this->setGraphicsEffect(shadow_effect);
}

void MessageBox::paintEvent(QPaintEvent *event)
{
    Q_UNUSED(event);

    int radius = 10;
    QPainter painter(this);                                                     // 圆角大小
    painter.setRenderHint(QPainter::Antialiasing);                              // 抗锯齿
    painter.setBrush(QBrush( QColor(255, 255, 255, 255), Qt::SolidPattern));    // 背景颜色，透明度
    painter.setPen(Qt::NoPen);
    painter.drawRoundedRect(0, 0, this->width(), this->height(), radius, radius);
}

MessageBox::~MessageBox()
{
    delete ui;
}
