#ifndef MESSAGE_BOX_H
#define MESSAGE_BOX_H

#include <QDialog>

namespace Ui {
class MessageBox;
}

class MessageBox : public QDialog
{
    Q_OBJECT

public:
    explicit MessageBox(QWidget *parent = nullptr);
    ~MessageBox();

private:
    Ui::MessageBox *ui;

protected:
    void paintEvent(QPaintEvent *event);
};

#endif // MESSAGE_BOX_H
